# QuickFill

Easy way to fill CNG.

## Table of Contents

1. [Basic Project Setup](#basic-project-setup)
2. [Coding Guidelines](#coding-guidelines)
3. [Miscellaneous](#miscellaneous)

### Basic Project Setup
#### To clone repository in vs code.

Press ctrl+p and press >
```
git clone https://ravikarn.visualstudio.com/_git/QuickFill
``` 
#### Firbase install
Terminal Commands
```
npm install firebase
npm install angularfire2
```

### Coding Guidelines
#### Checkin and Checkout Process
- To be done.

[More on how to format this file](https://en.wikipedia.org/wiki/Markdown#Example)
[Markdown Format Syntax](https://daringfireball.net/projects/markdown/syntax)