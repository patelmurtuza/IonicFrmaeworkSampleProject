import { Injectable } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { FirebaseListObservable } from 'angularfire2/database';

@Injectable()
export class Databaseservice {
  users: FirebaseListObservable<any>;
  items: FirebaseListObservable<any>;
  found: boolean = false;
  constructor(public af: AngularFireDatabase) {
  }
  public userCreateAccount(): FirebaseListObservable<any[]> {
    this.users = this.af.list('/Users', { preserveSnapshot: true });
    return this.users;
  }
  public PumpList(): FirebaseListObservable<any[]> {
    this.items = this.af.list('/Pumps');
    return this.items;
  }
  public feedBackPush(): FirebaseListObservable<any[]> {
    this.items = this.af.list('/FeedBack');
    return this.items;
  }
  public sortedPumpList(): FirebaseListObservable<any[]> {
    this.items = this.af.list('Pumps');
    return this.items;
  }
  public requestAppointment(): FirebaseListObservable<any[]> {
    this.items = this.af.list('/ActiveRequests');
    return this.items;
  }
  public getPumpQueue(): FirebaseListObservable<any[]> {
    this.items = this.af.list('/PumpQueue');
    return this.items;
  }
  public UpdateSelectedSlot(selecetedDay, selectedPump, slotId, vehicleNo): FirebaseListObservable<any[]> {
    let key: any = selectedPump + "/Day/" + selecetedDay + "/slots/" + slotId;
    this.af.object('/PumpQueue/' + key)
      .update({ booked: "true", VehicleNo: vehicleNo });
    this.items = this.af.list('/PumpQueue/' + key);
    return this.items;
  }

  public signIn(userId: string): FirebaseListObservable<any[]> {
    let signInResult: FirebaseListObservable<any>;
    if (Number(userId)) {
      signInResult = this.af.list('/Users', {
        query: {
          orderByChild: 'MobileNo',
          equalTo: userId
        }
      });
    }
    else {
      signInResult = this.af.list('/Users', {
        query: {
          orderByChild: 'Email',
          equalTo: userId
        }
      });
    }
    return signInResult;
  }

  public pushfavourite(UserNodeKey, pumpCity, pumpName, currentLatitude, currentLongitude, pumpAddress, pumpCompany): FirebaseListObservable<any[]> {
    let result: FirebaseListObservable<any>;
    let key: any = '/Users/' + UserNodeKey;
    result = this.af.list(key + '/favourites');
    result.push({
      PumpName: pumpName,
      PumpAddress: pumpAddress,
      PumpCompany: pumpCompany,
      PumpCity: pumpCity,
      PumpLatitude: currentLatitude,
      PumpLongitude: currentLongitude
    }).then(function (ref) {
      console.log("Key:", ref);
    }, function (error) {
      console.log("Error:", error);
    });
    return result;
  }
  public getFavouriteList(UserNodeKey): FirebaseListObservable<any[]> {
    let result: FirebaseListObservable<any>;
    let key: any = '/Users/' + UserNodeKey;
    result = this.af.list(key + '/favourites');
    return result;
  }
  public removeFavourites(UserNodeKey,pumpkey)
  {
    let result: FirebaseListObservable<any>;
    let key: any = '/Users/' + UserNodeKey;
    result = this.af.list(key + '/favourites');
    result.remove(pumpkey);
    return result;

  }
  public createPumpQueue(pumpName:string)
  {
    let pumpQueue:FirebaseListObservable<any>;
    let weekArray:Array<any>;
    weekArray=new Array();
    let i,j:any;
    pumpQueue= this.af.list('/PumpQueue/'+pumpName)
    pumpQueue.push({"name":pumpName}).key=pumpName;
     weekArray.push("Monday");
     for(i=0,i < weekArray.length;i++;){
// '/Day/'+weekArray[i]+'/slots/')
for(j=0;j<1440;j+=10)
 {
   pumpQueue.push({
booked:"false",
     time:0+':'+j   })
 }
}
  }
}